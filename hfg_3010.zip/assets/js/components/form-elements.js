$(function () {

	'use strict';
	$('select').uniform({
		selectAutoWidth: false
	});
	$('.uniform').uniform();
});